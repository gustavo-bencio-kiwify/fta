-- AlterTable
ALTER TABLE "tasks" ADD COLUMN     "slackOpenChannelId" TEXT,
ADD COLUMN     "slackOpenMessageTs" TEXT;
