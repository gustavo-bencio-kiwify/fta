-- AlterTable
ALTER TABLE "tasks" ADD COLUMN     "recurrenceAnchor" TIMESTAMP(3);
