-- AlterEnum
ALTER TYPE "Recurrence" ADD VALUE 'none';
